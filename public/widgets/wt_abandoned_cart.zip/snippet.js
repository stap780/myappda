$( document ).ready(function() {
  const userDataKey = "userData";
  const intervalForSend = 3000;

  window.timestamp = new Date().getTime();
  window.email = null;
  window.phone = null;
  window.sent = false;

  document.addEventListener("mousemove", SetTimestamp);
  document.addEventListener("click", SetTimestamp);
  document.addEventListener("keydown", SetTimestamp);
  document.body.addEventListener("mouseleave", function () {
    if (IsRegistered())
      GetRegisteredData();
    else
      GetUnregisteredData();
  });

  const emailInput = document.querySelector("input[name='client[email]']");
  const phoneInput = document.querySelector("input[name='client[phone]']");
  const shippingAddressPhone = document.querySelector("input[name='shipping_address[phone]']");

  if (emailInput !== null) emailInput.addEventListener("input", SetEmailValue.bind(event));
  if (phoneInput !== null) phoneInput.addEventListener("input", SetPhoneValue.bind(event));
  if (shippingAddressPhone !== null) shippingAddressPhone.addEventListener("input", SetPhoneValue.bind(event));

  setInterval(()=>{
    let send = (window.timestamp + intervalForSend) < new Date().getTime();

    if (send)
    {
      if (IsRegistered())
        GetRegisteredData();
      else
        GetUnregisteredData();
    }
  }, 1000);

  //If User Registered
  function GetRegisteredData()
  {
    let contacts = {
      phone: window.phone,
      email: window.email
    }

    let blocks = Array.from(document.querySelectorAll(".co-client-info .co-client-field"));

    blocks.forEach(function(el){
      if (el.innerText.match(/[a-zа-я0-9\.\-_]+@[a-zа-я0-9\.\-_]+\.[a-z0-9]+/im) !== null)
        window.email = el.innerText;
      else
        window.phone = el.innerText;
    });

    if (window.phone !== null || window.email !== null)
    {
      if (LocalStorageHas(userDataKey))
        ParseUpdateAndSendData();
      else
        CreateSaveAndSendData();
    }
  }

  // If user not registered
  function GetUnregisteredData() {
    let contacts = {
      phone: window.phone,
      email: window.email
    }

    let phoneInput = document.querySelector("input[name='client[phone]']");
    let emailInput = document.querySelector("input[name='client[email]']");

    if (phoneInput !== null)
      window.phone = phoneInput.value;

    if (emailInput !== null)
      window.email = emailInput.value;

    if (window.phone !== null || window.email !== null)
    {
      if (LocalStorageHas(userDataKey))
        ParseUpdateAndSendData();
      else
        CreateSaveAndSendData();
    }
  }

  // Utility Functions
  async function CreateSaveAndSendData()
  {
    let id = CreateUniqueId();

    let contacts = {
      phone: window.phone,
      email: window.email
    }

    let userDataObject = {
      id: id,
      contacts: contacts
    }

    userDataObject.contacts.phone = window.phone;

    let serializedData = JSON.stringify(userDataObject);

    localStorage.setItem(userDataKey, serializedData);

    let result = await SendToServer(userDataObject);
  }

  async function ParseUpdateAndSendData()
  {
    let data = JSON.parse(localStorage.getItem(userDataKey));

    if (data.contacts.email !== window.email || data.contacts.phone !== window.phone || window.sent === false)
    {
      data.contacts.email = window.email;
      data.contacts.phone = window.phone;

      localStorage.setItem(userDataKey, JSON.stringify(data));

      let result = await SendToServer(data);
      window.sent = true;
    }
  }

  async function SendToServer(data)
  {
    data.lines = GetOrderLines();
    data.insales_account_id = $('.abandoned_cart').data('account-id');
    var settings = {
      "url": "https://myappda.ru/insints/abandoned_cart",
      "method": "POST",
      "dataType": "json",
      "contentType": "application/json",
      "data": JSON.stringify(data),
    };

    if (data.lines && data.lines.length > 0 && data.contacts.email && data.contacts.email.length > 0 ) {
      $.ajax(settings).done(function (response) {
        console.log(response);
      });
    } else {
      console.log("===========");
      console.log("not send abandoned_cart");
      console.log("data.lines", data.lines );
      console.log("data.contacts.email => ", "/"+data.contacts.email+"/" );
      console.log("===========");
    }
  }

  function SetTimestamp()
  {
    window.timestamp = new Date().getTime();
    window.sent = false;
  }

  function SetEmailValue(e)
  {
    let target = e.target;

    if (target !== null)
      window.email = target.value;
  }

  function SetPhoneValue(e)
  {
    let target = e.target;

    if (target !== null)
      window.phone = target.value;
  }

  function LocalStorageHas(key)
  {
    return localStorage.getItem(key) !== null;
  }

  function IsRegistered()
  {
    let blocks = Array.from(document.querySelectorAll(".co-client-info .co-client-field"));

    if (blocks.length > 0)
      return true;

    return false;
  }

  function CreateUniqueId(idLength = 16)
  {
    const symbols = ("aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ0123456789!@#$^*()_+-=").split("");
    let first = [];

    for (let i = 0; i < idLength; i++)
      first.push(symbols[Math.floor(Math.random() * symbols.length)]);

    return first.sort(() => .5 - Math.random()).join("");
  }

  function GetOrderLines()
  {
    let lines = [];

    let orderLines = Cart.order.order_lines;

    if (orderLines && orderLines.length > 0)
      orderLines.forEach(function (orderLine) {
        let line = {
          productId: orderLine.product_id,
          variantId: orderLine.variant_id,
          quantity: orderLine.quantity,
          full_total_price: orderLine.full_total_price
        };

        lines.push(line);
      });

    return lines;
  }
});