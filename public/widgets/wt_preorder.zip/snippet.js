$(function () {
  $(function () {
    $widget.each(function (index, el) {
      new LazyLoad({
        container: $(el).get(0),
        elements_selector: ".lazyload",
      });
    });
  });

  EventBus.subscribe("show-preorder:insales:ui_product", (data) => {
    //console.log('var =>',document.querySelector('[data-variant-id]'));
    $(widget).addClass("is-show-fullscreen");

    const emailInput = document.querySelector('input[name="email"]');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    emailInput.addEventListener("input", () => {
      const value = emailInput.value.trim();
      if (value && !emailRegex.test(value)) {
        document.querySelector(
          ".preorder__field-error.mail-error"
        ).textContent = "Некорректный формат адреса электронной почты";
      } else {
        document.querySelector(
          ".preorder__field-error.mail-error"
        ).textContent = "";
      }
    });
  });

  $(document).ready(function () {
    $(widget)
      .find(".js-hide-preorder")
      .on("click", function () {
        $(widget).removeClass("is-show-fullscreen");
      });

    $(widget).on("click", function (event) {
      if ($(event.target).closest(widget + " .layout__content").length) {
        return;
      }

      $(widget).removeClass("is-show-fullscreen");
    });
  });

  // создаем уникальны id
  function CreateUniqueId(idLength = 16) {
    const symbols =
      "aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ0123456789!@#$%^*()_+-=".split(
        ""
      );
    let first = [];

    for (let i = 0; i < idLength; i++)
      first.push(symbols[Math.floor(Math.random() * symbols.length)]);

    return first.sort(() => 0.5 - Math.random()).join("");
  }

  // получаем форму и добавляем обработчик события submit
  const form = document.querySelector(".preorder-form-myappda");
  form.addEventListener("submit", (event) => {
    event.preventDefault(); // отменяем стандартное поведение формы

    // собираем данные из полей формы
    const name = form.querySelector('input[name="name"]').value.trim();
    const phone = form.querySelector('input[name="phone"]').value.trim();
    const email = form.querySelector('input[name="email"]').value.trim();
    const productId = form.querySelector("[data-feedback-product-id]").dataset
      .feedbackProductId;
    const variantId =
      document.querySelector("[data-variant-id]").dataset.variantId;
    const insales_account_id = form.querySelector("[data-feedback-account-id]")
      .dataset.feedbackAccountId;
    const id = CreateUniqueId(); //form.querySelector('button[type="submit"]').dataset.feedbackId;
    // создаем объект данных
    const data = {
      id: id,
      contacts: {
        phone: phone,
        email: email,
        name: name,
      },
      lines: [
        {
          productId: productId,
          variantId: variantId,
          quantity: 1,
        },
      ],
      insales_account_id: insales_account_id,
    };
console.log ('preorder',JSON.stringify(data))
    // отправляем данные на сервер
    fetch("https://myappda.ru/insints/preorder", {
      method: "POST",
      contentType: "application/json",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        console.log("response===>", response);
        if (response.ok) {
          // показываем сообщение об успешной отправке формы
          form.querySelector(".preorder__success-message").style.display =
            "block";
          // очищаем поля формы
          form.reset();
          setTimeout(function () {
            $(widget).removeClass("is-show-fullscreen");
          }, 2000);
        } else {
          throw new Error("Network response was not ok");
        }
      })
      .catch((error) => {
        console.error("There was a problem with the fetch operation:", error);
      });
  });
});
