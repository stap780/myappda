$(function () {
  // close form use close button
  $(widget).find(".js-hide-preorder").on("click", function () {
    $(widget).removeClass("is-show-fullscreen");
  });
  // close form use click outside form
  $(widget).on("click", function (event) {
    if ($(event.target).closest(widget + " .layout__content").length) {
      return;
    }
    $(widget).removeClass("is-show-fullscreen");
  });
  // open form
  EventBus.subscribe("show-preorder:insales:ui_product", (data) => {
    $(widget).addClass("is-show-fullscreen");
  });

  // создаем уникальны id
  function CreateUniqueId(insales_account_id) {
    var idLength = 16;
    const symbols =
      (insales_account_id + "aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ0123456789!@#$%^*()_+-=").split("");
    let first = [insales_account_id];

    for (let i = 0; i < idLength; i++)
      first.push(symbols[Math.floor(Math.random() * symbols.length)]);

    return first.sort(() => 0.5 - Math.random()).join("");
  }

  // получаем форму и добавляем обработчик события submit
  const form = document.querySelector(".preorder-form-myappda");
  form.addEventListener("submit", (event) => {
    // отменяем стандартное поведение формы
    event.preventDefault();
    // собираем данные из полей формы
    const name = form.querySelector('input[name="name"]').value.trim();
    const phone = form.querySelector('input[name="phone"]').value.trim();
    const email = form.querySelector('input[name="email"]').value.trim();
    const productId = form.querySelector("[data-feedback-product-id]").dataset.feedbackProductId;
    const variantId = document.querySelector("[data-variant-id]").dataset.variantId;
    const insales_account_id = form.querySelector("[data-feedback-account-id]").dataset.feedbackAccountId;
    console.log('insales_account_id',insales_account_id)
    const id = CreateUniqueId(insales_account_id);
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    var phonePattern = /^\+?[1-9]\d{1,11}$/;
    // создаем объект данных
    const data = {
      id: id,
      contacts: {
        phone: phone,
        email: email,
        name: name,
      },
      lines: [
        {
          productId: productId,
          variantId: variantId,
          quantity: 1,
        },
      ],
      insales_account_id: insales_account_id,
    };
    if (!emailPattern.test(email)) {
      form.querySelector(".preorder__field-error.mail-error").textContent = "Некорректный формат адреса электронной почты";
      return false;
    } else {
      form.querySelector(".preorder__field-error.mail-error").textContent = "";
    }
    if (!phonePattern.test(phone)) {
      form.querySelector(".preorder__field-error.phone-error").textContent = "Некорректный формат телефона";
      return false;
    } else {
      form.querySelector(".preorder__field-error.phone-error").textContent = "";
    }
    // console.log ('preorder',JSON.stringify(data))  
    // отправляем данные на сервер
    fetch("https://myappda.ru/insints/preorder", {
      method: "POST",
      contentType: "application/json",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        // console.log("response =>", response);
        if (response.ok) {
          // показываем сообщение об успешной отправке формы
          form.querySelector(".preorder__success-message").style.display = "block";
          // очищаем поля формы
          form.reset();
          setTimeout(function () {
            $(widget).removeClass("is-show-fullscreen");
          }, 2000);
        } else {
          throw new Error("Network response was not ok");
        }
      })
      .catch((error) => {
        console.error("There was a problem with the fetch operation:",error);
      });
  });
});