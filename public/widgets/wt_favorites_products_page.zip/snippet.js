$(document).ready(function(){
  var mobile_point = 767;

// Склонение слов
// @param  {number} _day  число
// @param  {array} titles массив слов
// @return {string}       склонение
//
// declinationText(2, ['человек', 'человека', 'человек'])
// => 'человека'
 
  var declinationText = function (_day, titles) {
    var day = Math.round(_day);
    var _titles = ["цвет", "цвета", "цветов"];
    if (titles) {
      _titles = titles;
    }
    var cases = [2, 0, 1, 1, 1, 2];
    return _titles[
      day % 100 > 4 && day % 100 < 20 ? 2 : cases[day % 10 < 5 ? day % 10 : 5]
    ];
  };

  function getClient() {
    return ajaxAPI.shop.client.get().done(function (onDone) { onDone });
  }
  
  function getIzbPage() {
    var url = "https://myappda.ru/insints/getizb"
    var shop = Shop.config.get();
    var accountId = shop.account_id;
    var products;
    $.when( getClient() ).done(function ( client ) {
      var data = { insales_account_id: accountId, client_id: client.id };
      $.ajax({
        "url": url,
        "async": false,
        "data": data,
        "dataType": "json"
      }).done(function( data ) {
        products = data.products;
        // console.log( "products ", products);
        fillIzbPage(products);
      }).fail(function( textStatus, error ) {
        var err = textStatus + ", " + error;
      // console.log( "Request Failed: " + err );
      });
    });
    setTimeout(() => {
      return products;
    }, 800)
  }

  function sortProductsByIds(productIds, productsObj) {
    // Возвращаем массив товаров, отсортированный как в productIds
    return productIds.map(id => productsObj[id]);
  }

  // $widget.each(function(index, el) {
    // let $widget = $(el)
    function fillIzbPage(products){
      let viewed_products = products.split(",");
      if (viewed_products) {

        if (viewed_products.length == 0) {
          $widget.addClass("is-empty-viewed_products");
          return false;
        }

        let viewed_grid = $widget.find(".js-our-special-products-grid");
        let price_label = viewed_grid.data("priceLabel");

        Products.getList(viewed_products).done(function(data) {
          const sortedProducts = sortProductsByIds(viewed_products, data);

          //sortedProducts.slice(0,4).forEach(item_info => {
          sortedProducts.forEach(item_info => {  
            if (!item_info) { return; }

            let product_elem = addViewedProduct(item_info, price_label);
            // console.log('viewed_products product_elem =>', product_elem);
            viewed_grid.append(product_elem);

          });

          new LazyLoad({
            container: $widget.get(0),
            elements_selector: '.lazyload',
            use_native: 'loading' in document.createElement('img')
          });

        }).fail(function(onFail) { console.log('onFail', onFail) });
      } else {
        $widget.addClass("is-empty-viewed_products");
      }
    };  
  // });

  function addViewedProduct(productData, priceLabel) {
    // console.log('viewed_products productData =>', productData);
    let price_label = '';
    let cvetOptionValues = getCvetOptionValues(productData.options);
    // console.log('viewed_products cvetOptionValues =>', cvetOptionValues);
    let cvetOptionValuesSize = Object.keys(cvetOptionValues).length;
    let cvetText = declinationText(cvetOptionValuesSize);
    let sliderImages = '';
    $.each(productData.images, function( index, image ){
      let firstLoadClass = '';
      if(image.id === productData.first_image.id){firstLoadClass = 'first-load'};

      sliderImages +=  `<a href="${productData.url}" class="swiper-slide" data-image-id="${image.id}" data-image-index="${index}">
                          <div class="img-ratio img-ratio_cover">
                            <div class="img-ratio__inner">  
                            <picture>
                              <source data-srcset="${image.large_url}" type="image/webp" class="lazyload" />
                              <img data-src="${image.large_url}" alt="${productData.title}" title="${productData.title}" class="lazyload" />
                            </picture>
                            </div>
                          </div>
                        </a> `

    }); 
    let mainImages = '';
    $.each(productData.images, function( index, image ){
      let firstLoadClass = '';
      if(image.id === productData.first_image.id){firstLoadClass = 'first-load'};

      mainImages +=  `<a href="${productData.url}" class="main-image ${firstLoadClass}" data-image-id="${image.id}">
        <div class="img-ratio img-ratio_cover">
          <div class="img-ratio__inner">
          <picture>
            <source data-srcset="${image.large_url}" type="image/webp" class="lazyload">
            <img data-src="${image.large_url}" alt="${productData.title}" title="${productData.title}" class="lazyload">
          </picture>
          </div>
        </div>
        </a> `

    });

    if (productData.price_varies) {
      price_label = `<span class="viewed-product__price-label">${priceLabel}</span>`;
    }
    return `
    <div class="product-item with-sale-value with-old-price without-sku is-available" data-product-id="${productData.id}">
      <div class="product-item_top">
        <div class="product-item_image">
            <div class="sticker-container"></div>
            <span class="button button_size-s favorites_btn favorites-added" data-trigger-click="myappda-favorites-trigger:insales:site" data-favorite-product="${productData.id}">
              <span class="btn-icon icon-favorites-o"></span>
              <span class="btn-icon icon-favorites-f"></span>
            </span>
            <div class="slider-images swiper-container js-product-item-images">
                <div class="swiper-wrapper">                     
                  ${sliderImages}
                </div>
                <div class="navigation">
                  <div class="swiper-prev" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-56813871267bb01c" aria-disabled="false"></div>
                  <div class="swiper-next" tabindex="0" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-56813871267bb01c" aria-disabled="false"></div>
                </div>                
                <div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets"></div>                     
            <span class="swiper-notification"></span></div>

            <div class="hover-wrap js-prevent-images">
              <div class="main-images">
                  ${mainImages}                     
              </div>
              <span class="hide" name="variant_id" data-product-variants='{ "Цвет": "custom-option-preview","default": "option-span"}' ></span>
            </div>                     
        </div>
      </div>
      <div class="product-item_info js-preload-block">
        <div class="product-item_title">
          <a class="link-hover-underline" href="${productData.url}">${productData.title}</a> 
        </div>
        <div class="product-item_prices">
          <div class="product-preview__price">
            <span class="product-price product-preview__price-cur" data-product-card-price-from-cart="">${Shop.money.format(productData.price_min)}</span>
          </div>
          <div class="product-old_price product-preview__price-old" data-product-card-old-price="">${Shop.money.format(productData.old_price)}</div>
        </div> 
        <div class="product-item_color_info">${cvetOptionValuesSize} ${cvetText}</div>
      </div>
    </div>
    `;
  }

  function getCvetOptionValues(options){
    var opt = $.map( options, function( option, index) {
        if(option.handle === 'cvet'){
          return option.values;
        }
      });
    return opt[0];
  }

  setTimeout(() => {
    initRevProducts($widget, true);
  }, 1000);

  function initRevProducts(parent, updateInstance){
    // console.log('start initRevProducts from recent view');
    parent.each(function(index, el) {
      let lazyLoadBannerList = new LazyLoad({
        container: $(el).get(0),
        elements_selector: '.lazyload'
      });
    });

    parent.find(".js-product-item-images").each(function(){
      initImagesSlider($(this));
    });

    function initImagesSlider(slider) {
      var imagesSlider = new Swiper(slider.get(0), {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: false,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        navigation: {
          prevEl: '.swiper-prev',
          nextEl: '.swiper-next'
        },
        watchOverflow: true
      });
    }

    setTimeout(() => {
      parent.find('.first-load').each(function(index, el){
        // если выделять картинку варианта по главной картинке товара
        var thisEl = $(this);
        thisEl.addClass('is-active');
        var imageId = thisEl[0].dataset.imageId;
        var searchImageClass = '.hover-image[data-image-id="'+imageId+'"]';
        var imagesNode = thisEl.closest('.hover-wrap');
        if (imagesNode.find(searchImageClass)){
          // console.log('present', searchImageClass);
          imagesNode.find('.hover-images .is-active').removeClass('is-active');
          imagesNode.find(searchImageClass).addClass('is-active');
        }
      });
    }, 1000);

    setTimeout(() => {
      parent.find('.hover-image').each(function(index, el){
        // если заглавной картинкой ставить картинку первого варианта
        // var thisEl = $(this);
        // var imageId = thisEl[0].dataset.imageId;
        // var searchImageClass = '.main-image[data-image-id="'+imageId+'"]'
        // var imagesNode = thisEl.closest('.hover-wrap');
        // imagesNode.find('.main-images .is-active').removeClass('is-active');
        // imagesNode.find('.hover-images .is-active').removeClass('is-active');
        // imagesNode.find(searchImageClass).addClass('is-active');
        // thisEl.addClass('is-active');
      });
    }, 1000);

    setTimeout(() => {
      parent.find('.hover-image').mouseenter(function(e){
        var thisEl = $(this);
        var imageId = thisEl[0].dataset.imageId;
        var searchImageClass = '.main-image[data-image-id="'+imageId+'"]'
        var imagesNode = thisEl.closest('.hover-wrap');
        imagesNode.find('.main-images .is-active').removeClass('is-active');
        imagesNode.find('.hover-images .is-active').removeClass('is-active');
        imagesNode.find(searchImageClass).addClass('is-active');
        thisEl.addClass('is-active');
      });
    }, 1000);

    if(updateInstance == true){
      parent.find('[data-product-id]').each(function(index, el){
        Products.initInstance($(el));
        FavoritesProducts.update();
      });
    }

    parent.find('.js-prevent-images').on('click', function(e){
      if($(window).width() <= 767){
        e.preventDefault();
      }
    });

    EventBus.subscribe('remove_item:insales:favorites_products', (data) => {
      if(parent.find('[data-remove-favorites]').attr('data-remove-favorites') == 'true'){
        var parentEl = parent.find('[data-remove-favorites]');
        parentEl.find(`[data-product-id="${data.action.item}"]`).parents('.product-item:first').fadeOut(300);

        if(data.products.length == 0){
          parent.find('.empty-catalog-message').removeClass('hidden');
        }
      }
    });


    EventBus.subscribe('update_variant:insales:product', function(variant){
      var widgetClass = widget.substring(1);
      if($(variant.action.product[0]).parents('.layout:first').hasClass(widgetClass)){
        $(variant.action.product[0]).find('.option-value.is-active').each(function(){
          var thisEl = $(this);
          var thisVal = '';
          if(thisEl.hasClass('is-preview')){
            thisVal = thisEl.find('img').attr('title');
          } else{
            thisVal = thisEl.html();
          }
          var thisParent = thisEl.parents('.option:first');

          if(!thisParent.hasClass('done')){
            var lbl = thisParent.find('.option-label')
            var lblHtml = lbl.html().slice(-1);
            var koma = '';
            if(lblHtml != ':'){
              var koma = ':'
            }
            lbl.append(`${koma} <span>${thisVal}</span>`);
          }
          thisParent.addClass('done');
        }); 
        
        if($(variant.action.product[0]).find('.hover-images').length > 0){
          $(variant.action.product[0]).find('.hover-image.is-active').removeClass('is-active');
          if(variant.image_id != null){
            $(variant.action.product[0]).find(`[data-image-id="${variant.image_id}"].hover-image`).addClass('is-active');
          } else{
            $(variant.action.product[0]).find('.hover-image:first-child').addClass('is-active');
          }
        } else{
          var imagesSlider = $(variant.action.product[0]).find('.js-product-item-images')[0].swiper;
          if(variant.image_id != null){
            var dataIndex = $(variant.action.product[0]).find(`[data-image-id="${variant.image_id}"].swiper-slide`).attr('data-image-index') * 1;
            imagesSlider.slideTo(dataIndex);
          } else{
            imagesSlider.slideTo(0);
          }
        }
      }
    });

  }

  $.get( "https://myappda.ru").done(function( data ) {
    getIzbPage();
  });

});