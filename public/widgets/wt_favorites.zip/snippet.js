$(function() {

  function getClient() {
    return ajaxAPI.shop.client.get().done(function (onDone) { onDone });
  }

  EventBus.subscribe("myappda-favorites-trigger:insales:site", (data) => {
    // console.log("myappda-favorites-trigger:insales:site", data.event_target);
    var element =  data.event_target;
    var productId = element.dataset.favoriteProduct;
    var prNode = element.closest('[data-product-id="'+productId+'"]');
    var favButton = $('[data-favorite-product="'+productId+'"]');
    var counter = $('[data-ui-favorites-counter]');
    $(counter).removeClass('favorites-empty');
    var variantId = prNode.dataset.variantId;
    var shop = Shop.config.get();
    var accountId = shop.account_id;
    var result = false;
    $.when( getClient() ).done(function ( client ) {
      // console.log ('client => ', client );
      var data = { insales_account_id: accountId, client_id: client.id, product_id: productId, variant_id: variantId };
      // console.log('data => ',data)
      var added = false;
      if ($(favButton).hasClass('favorites-added')) {
        added = true;
      }
      // console.log('added? => ', added)
      if (added) { //delete fav
        var url = "https://myappda.ru/insints/deleteizb"
        $.ajax({
          "url": url,
          "data": data,
          "dataType": "json"
        }).done(function( data ) {
          $(counter).text(data.totalcount);
          $(favButton).removeClass('favorites-added');
          $('.fav-coll-products').find('[data-product-id="'+productId+'"]').hide();
        }).fail(function( textStatus, error ) {
          var err = textStatus + ", " + error;
        //  console.log( "Request Failed: " + err );
        });
      } else { //add fav
        var url = "https://myappda.ru/insints/addizb"
        $.ajax({
          "url": url,
          "data": data,
          "dataType": "json"
        }).done(function( data ) {
          $(counter).text(data.totalcount);
          $(favButton).addClass('favorites-added');
        }).fail(function( textStatus, error ) {
          var err = textStatus + ", " + error;
        //  console.log( "Request Failed: " + err );
        });
      }
      result = true;
    });
    setTimeout(() => {  
        if ( result == false ){
          alert ('Пожалуйста зарегистрируйтесь')
        }
    }, 700)
  });

  function getIzb() {
    var url = "https://myappda.ru/insints/getizb"
    var shop = Shop.config.get();
    var accountId = shop.account_id;
    var products;
    $.when( getClient() ).done(function ( client ) {
      var data = { insales_account_id: accountId, client_id: client.id };
      $.ajax({
        "url": url,
        "async": false,
        "data": data,
        "dataType": "json"
      }).done(function( data ) {
        products = data.products;
        fillIzbProducts(products);
      }).fail(function( textStatus, error ) {
        var err = textStatus + ", " + error;
      // console.log( "Request Failed: " + err );
      });
    });
  }

  function fillIzbProducts(products){
    if(products && products != " ") {
      var counter = $('[data-ui-favorites-counter]');
      $(counter).removeClass('favorites-empty');
      var arrProd =  products.split(",");
      $(counter).text(arrProd.length);
      $.each(arrProd, function(key, value) {
        // console.log("izb товар", value)
        var favButton = $('[data-favorite-product="'+value+'"]');
        $(favButton).addClass('favorites-added');
      });
    }
  }


  $.get( "https://myappda.ru").done(function( data ) {
    getIzb();
  });

});
